<?php
/**
 * The template for displaying the footer
 *
 * @package     Snazzy
 * @link        https://themebeans.com/themes/snazzy
 * @author      Rich Tabor of ThemeBeans <hello@themebeans.com>
 * @copyright   Copyright (c) 2018, ThemeBeans of Inventionn LLC
 * @license     GPL-3.0
 */

if ( ! is_404() ) { ?>

	</div>

<?php
}

wp_footer();
?>

</body>

</html>
